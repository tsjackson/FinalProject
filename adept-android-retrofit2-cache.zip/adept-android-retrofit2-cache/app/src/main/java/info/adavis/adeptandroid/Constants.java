package info.adavis.adeptandroid;

/**
 * @author Annyce Davis
 */
public class Constants
{
    public static final String BASE_URL = "http://10.0.0.40:8080";
}
