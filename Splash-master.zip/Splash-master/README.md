# Splash
An example of a splash screen done the right way on Android

![](art/sample_splash.gif)
